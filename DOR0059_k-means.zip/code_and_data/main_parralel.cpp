#include <omp.h>
#include <stdio.h>
#include <stdlib.h>
#include <c++/v1/vector>
#include <c++/v1/string>
#include <iostream>
#include <fstream>
#include <string>
#include <sstream>
#include <random>
#include <ctime>

void getNewMeans(std::vector<std::vector<double> > &points, std::vector<int> &labels, std::vector<std::vector<double> > &means)
{
  std::vector<std::vector<double> > newMeans(means.size(), std::vector<double>(means[0].size(), 0));
  std::vector<int>                  countsForMean(means.size(), 0);
  if(points.size() != labels.size())
    throw std::invalid_argument("Points need to be the same size as labels");

  for (int i = 0; i < points.size(); ++i) {
    int meansItter = labels[i];
    countsForMean[meansItter]++;

#pragma omp simd
    {
      for (int j = 0; j < points[i].size(); ++j)
        newMeans[meansItter][j] = newMeans[meansItter][j] + points[i][j];
    }

  }

  for (int i = 0; i < newMeans.size(); ++i) {
#pragma omp simd
    {
      for (int j = 0; j < newMeans[i].size(); ++j) {
        newMeans[i][j] = newMeans[i][j] / countsForMean[i];
      }
    }
  }

  means = newMeans;
}

double distanceBetween(std::vector<double> &pointA, std::vector<double> &pointB)
{
  double squaredDistance = 0;

  if(pointA.size() != pointB.size())
    throw std::invalid_argument("Point A needs to be the same size as Point B");

  for (int i = 0; i < pointA.size() ; ++i) {
    squaredDistance = squaredDistance + (pointA[i] - pointB[i])*(pointA[i] - pointB[i]);
  }
  return sqrt(squaredDistance);
}

int getLabels(std::vector<std::vector<double> > &points, std::vector<int> &labels, std::vector<std::vector<double> > &centroids)
{
  int changed = 0;

#pragma omp parallel for reduction(+ : changed)
  for (int i = 0; i < points.size(); ++i) {
    double closestDistance = distanceBetween(points[i], centroids[0]);
    int closestDistanceCentroidItter = 0;
    for (int j = 1; j < centroids.size(); ++j) {
      double currDistance = distanceBetween(points[i], centroids[j]);
      if(currDistance < closestDistance) {
        closestDistance = currDistance;
        closestDistanceCentroidItter = j;
      }
    }
    if(closestDistanceCentroidItter != labels[i])
      changed++;

    labels[i] = closestDistanceCentroidItter;
  }
  return changed;
}

void calcClosestDistances(std::vector<std::vector<double> > &points, std::vector<std::vector<double> > &centroids, std::vector<double> &distances)
{
#pragma omp parallel for
  for (int i = 0; i < points.size(); ++i) {
    double bestDistance = distanceBetween(points[i], centroids[0]);
    for (int j = 1; j < centroids.size(); ++j) {
      double distance = distanceBetween(points[i], centroids[j]);
      if (distance < bestDistance)
        bestDistance = distance;
    }
    distances[i] = bestDistance;
  }
}

void standardInitCenters(int amountOfClusters, std::vector<std::vector<double> > &points, std::vector<std::vector<double> > &initCentroids)
{
  throw "Not implemented, use only `k++` flag";
}

void kMeansPP(int amountOfClusters, std::vector<std::vector<double> > &points, std::vector<std::vector<double> > &initCentroids)
{
  std::random_device  rd;
  std::mt19937        gen(rd());
  int                 amountOfPoints = points.size();
  std::vector<double> weights(amountOfPoints, 1.0);

  for (int i = 0; i < amountOfClusters; ++i)
  {
    std::discrete_distribution<>  dis(weights.begin(), weights.end());

    initCentroids.push_back(points[dis(gen)]);
    calcClosestDistances(points, initCentroids, weights);
    continue;
  }

}

void kMeans(int amountOfClusters, std::vector<std::vector<double> > points, std::vector<int> &labels, std::vector<std::vector<double> > &centroids, std::string initMethodFlag = NULL)
{
  int maxItterations = 1000;
  int currItterations = 0;
  int stopLimitChanged = floor(points.size()/100.0);
  labels = std::vector<int>(points.size(), -1);
  if(initMethodFlag == "k++")
    kMeansPP(amountOfClusters, points, centroids);
  else
    standardInitCenters(amountOfClusters, points, centroids);
  while(getLabels(points, labels, centroids) > stopLimitChanged)
  {
    getNewMeans(points, labels, centroids);
    if(currItterations > maxItterations)
      throw "Too many itterations!";
    currItterations++;
  }


}



void parseCSV(const char name[], std::vector<std::vector<double> > &points)
{

  std::ifstream   data(name);
  std::string     line;

  while(std::getline(data,line))
  {
    std::stringstream         lineStream(line);
    std::string               cell;
    std::vector<double>       parsedRow;

    while(std::getline(lineStream,cell,','))
    {
      parsedRow.push_back(stod(cell));
    }
    points.push_back(parsedRow);

  }
}

int main (int argc, char *argv[])
{
  for (int i = 0; i < 5; ++i) {
    const char fileName[] = "SIFTfeatures.csv";
    int amountOfClusters = 32;
    std::vector<std::vector<double> > points;
    std::vector<std::vector<double> > centroids;
    std::vector<int> labels;

    parseCSV(fileName, points);

    //timing start
    auto start = std::chrono::steady_clock::now();
    clock_t tStart = clock();

    //alg start
    kMeans(amountOfClusters, points, labels, centroids, "k++");

    //timing end
    auto end = std::chrono::steady_clock::now();

    double clockTime = ((double) (clock() - tStart) / CLOCKS_PER_SEC) * 1000;
    double actualTime = std::chrono::duration<double, std::milli>(end - start).count();
    std::cout << "Itteration: " << i << std::endl;
    printf("Clock time taken: %.1f ms\n", clockTime);
    std::cout << "Actual time taken: " << actualTime << " ms" << std::endl;

    std::ofstream myfile;
    myfile.open("times_parallel_32.csv", std::ios::app);
    myfile << clockTime << "," << actualTime << std::endl;
    myfile.close();
  }
}